import { useMemo } from "react";
import { Navigate, useParams } from "react-router-dom";
import { ConstraintCallout } from "../components/case-study/ConstraintCallout";
import { DecisionBlock } from "../components/case-study/DecisionBlock";
import { FieldNote } from "../components/case-study/FieldNote";
import { ProjectHeader } from "../components/case-study/ProjectHeader";
import { PullQuote } from "../components/case-study/PullQuote";
import { StickyCaseStudyNav } from "../components/case-study/StickyCaseStudyNav";
import { SystemSnapshot } from "../components/case-study/SystemSnapshot";
import { PageContainer } from "../components/layout/PageContainer";
import { Section } from "../components/layout/Section";
import { BodyText, SectionTitle } from "../components/primitives/Typography";
import { getCaseStudyTemplateContent } from "../case-studies/registry";

export const CaseStudyPage = () => {
  const { slug } = useParams();
  const study = useMemo(() => getCaseStudyTemplateContent(slug), [slug]);

  if (!study) {
    return <Navigate to="/" replace />;
  }

  const sectionLinks = [
    { id: "problem-framing", label: "Problem framing" },
    { id: "constraints", label: "Constraints" },
    { id: "decisions", label: "Decision sections" },
    { id: "system-explanation", label: "System explanation" },
    { id: "outcome-reflection", label: "Outcome / reflection" },
  ];

  return (
    <PageContainer
      rail={
        <StickyCaseStudyNav
          title={study.title}
          metadata={[
            { label: "Role", value: study.role },
            { label: "Timeline", value: study.timeline },
            { label: "Domain", value: study.domain },
            { label: "Outcome", value: study.outcome },
          ]}
          links={sectionLinks}
        />
      }
      stickyRailOnDesktop
      collapsibleRailOnMobile
      mobileRailLabel="Project overview"
      mainClassName="mx-auto w-full max-w-content"
    >
      <ProjectHeader
        title={study.title}
        subtitle={study.subtitle}
        role={study.role}
        timeline={study.timeline}
        domain={study.domain}
        outcome={study.outcome}
        tags={study.tags}
      />

      <Section id="problem-framing" spacing="lg">
        <SectionTitle>Problem framing</SectionTitle>
        {study.sections.map((section) => (
          <div key={section.id} className="space-y-2">
            <p className="type-caption">{section.label}</p>
            <BodyText className="max-w-prose">{section.body}</BodyText>
          </div>
        ))}
      </Section>

      <Section id="constraints" spacing="md">
        <SectionTitle>Constraints</SectionTitle>
        <div className="grid gap-5 md:grid-cols-2">
          {study.constraints.map((constraint) => (
            <ConstraintCallout key={constraint.title} title={constraint.title} detail={constraint.detail} />
          ))}
        </div>
      </Section>

      <Section id="decisions" spacing="lg">
        <SectionTitle>Decision sections</SectionTitle>
        <div className="flex flex-col gap-8">
          {study.decisions.map((decision) => (
            <DecisionBlock
              key={decision.title}
              title={decision.title}
              rationale={decision.rationale}
              impact={decision.impact}
            />
          ))}
        </div>
      </Section>

      <Section id="system-explanation" spacing="lg">
        <SectionTitle>System explanation</SectionTitle>
        <BodyText className="max-w-prose">
          The operating model balances fast scanability for routine work with deeper detail for edge-case
          review. Snapshot metrics below show the system behavior after rollout.
        </BodyText>
        <div className="grid gap-4 md:grid-cols-2">
          {study.snapshots.map((snapshot) => (
            <SystemSnapshot key={snapshot.title} title={snapshot.title} value={snapshot.value} note={snapshot.note} />
          ))}
        </div>
      </Section>

      <Section id="outcome-reflection" spacing="lg">
        <SectionTitle>Outcome / reflection</SectionTitle>
        <BodyText className="max-w-prose">{study.outcome}</BodyText>
        <PullQuote quote={study.quote} attribution={study.quoteAttribution} />
        <div className="grid gap-4">
          {study.fieldNotes.map((note) => (
            <FieldNote key={note}>{note}</FieldNote>
          ))}
        </div>
      </Section>

    </PageContainer>
  );
};
